import { gregorianToHijri } from './gregorianToHijri';
import { hijriToGregorian } from './hijriToGregorian';

export { gregorianToHijri, hijriToGregorian };

export type DateType = {
  year: number;
  month: number;
  day: number;
};

module.exports = {
  rules: {
    '@typescript-eslint/no-var-requires': 'off',
  },
};
